if (confirm("Just be on the right side of history.")) {
	txt="next";
}	else{
	txt="back"
};

$(".large").html("Kanders (Forbes estimates his net worth at $700 million) is the majority owner and CEO of Safariland LLC, a global defense manufacturer based in Jacksonville, Florida. Besides tear gas, the company sells riot gear, bomb suits, body armor, and pepper spray, among other products.");
