document.body.style.backgroundImage='url("https://www.investopedia.com/thmb/djn1J-yvlrMGaGg3M0iQPOsYQUw=/1500x1003/filters:fill(auto,1)/GettyImages-1054017850-7ef42af7b8044d7a86cfb2bff8641e1d.jpg")';

if (confirm("its ok if you do")) {
	txt="next";
}	else{
	txt="back"
};

$(".large").html("Shady business only  Sorry come again next year.");
